import 'dotenv/config'
import express from 'express'
import Stripe from 'stripe'

const { STRIPE_SECRET_KEY, PORT = 4242 } = process.env
const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null

const app = express()
app.use(express.json())

// Creates a PaymentIntent for a one-time donation. Amount is in whole dollars from the client
// and validated here; the secret key never leaves the server.
app.post('/api/create-payment-intent', async (req, res) => {
  if (!stripe) return res.status(500).json({ error: 'STRIPE_SECRET_KEY is not set on the server.' })

  const dollars = Number(req.body?.amount)
  if (!Number.isFinite(dollars) || dollars < 1 || dollars > 10000) {
    return res.status(400).json({ error: 'Donation must be between $1 and $10,000.' })
  }

  try {
    const intent = await stripe.paymentIntents.create({
      amount: Math.round(dollars * 100),
      currency: 'usd',
      automatic_payment_methods: { enabled: true },
      description: 'Active Youth Athletics donation',
    })
    res.json({ clientSecret: intent.client_secret })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Could not start payment.' })
  }
})

app.listen(PORT, () => console.log(`Stripe server listening on :${PORT}`))
