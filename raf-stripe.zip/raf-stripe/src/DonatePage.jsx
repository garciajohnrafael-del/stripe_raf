import { useEffect, useMemo, useState } from 'react'
import { loadStripe } from '@stripe/stripe-js'
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js'
import { HeartHandshake, Lock } from 'lucide-react'

const publishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY
const stripePromise = publishableKey ? loadStripe(publishableKey) : null

const PRESETS = [10, 25, 50, 100]

function CheckoutForm({ amount, onBack }) {
  const stripe = useStripe()
  const elements = useElements()
  const [submitting, setSubmitting] = useState(false)
  const [message, setMessage] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!stripe || !elements) return

    setSubmitting(true)
    setMessage('')

    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      redirect: 'if_required',
      confirmParams: { return_url: `${window.location.origin}/?donation=success` },
    })

    if (error) {
      setMessage(error.message || 'Something went wrong.')
      setSubmitting(false)
      return
    }

    if (paymentIntent?.status === 'succeeded') {
      window.location.href = `${window.location.origin}/?donation=success`
      return
    }

    setSubmitting(false)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      {message && <p role="alert" className="text-sm text-red-600 font-medium">{message}</p>}
      <button
        disabled={!stripe || submitting}
        className="w-full bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white py-4 rounded-md font-bold uppercase tracking-wider transition-colors"
      >
        {submitting ? 'Processing…' : `Donate $${amount}`}
      </button>
      <button type="button" onClick={onBack} className="w-full text-sm text-slate-500 hover:text-slate-800 font-semibold">
        ← Change amount
      </button>
    </form>
  )
}

export default function DonatePage() {
  const [amount, setAmount] = useState(25)
  const [custom, setCustom] = useState('')
  const [clientSecret, setClientSecret] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [success] = useState(() => new URLSearchParams(window.location.search).get('donation') === 'success')

  useEffect(() => {
    if (success) window.history.replaceState({}, '', window.location.pathname)
  }, [success])

  const options = useMemo(
    () => ({
      clientSecret,
      appearance: { theme: 'stripe', variables: { colorPrimary: '#ea580c', borderRadius: '6px' } },
    }),
    [clientSecret],
  )

  const startCheckout = async () => {
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Request failed')
      setClientSecret(data.clientSecret)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const validAmount = Number.isFinite(amount) && amount >= 1 && amount <= 10000

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <div className="bg-slate-900 py-20 text-center">
        <h1 className="text-4xl md:text-6xl font-black text-white uppercase italic tracking-tight">
          Fuel the <span className="text-orange-500">Game</span>
        </h1>
      </div>

      <div className="max-w-xl mx-auto px-4 -mt-10">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8 md:p-10">
          {success ? (
            <div className="text-center py-6">
              <HeartHandshake className="h-12 w-12 text-emerald-600 mx-auto mb-4" />
              <h2 className="text-2xl font-black uppercase italic text-slate-900 mb-2">Thank you!</h2>
              <p className="text-slate-600">Your donation is helping put gear in kids' hands.</p>
            </div>
          ) : !stripePromise ? (
            <p className="text-slate-600">
              Donations are not configured yet. Set <code>VITE_STRIPE_PUBLISHABLE_KEY</code> in <code>.env</code>.
            </p>
          ) : clientSecret ? (
            <Elements stripe={stripePromise} options={options}>
              <CheckoutForm amount={amount} onBack={() => setClientSecret(null)} />
            </Elements>
          ) : (
            <div className="space-y-6">
              <h2 className="text-xl font-black uppercase tracking-wide text-slate-900">Choose an amount</h2>
              <div className="grid grid-cols-4 gap-3">
                {PRESETS.map((p) => (
                  <button
                    key={p}
                    onClick={() => { setAmount(p); setCustom('') }}
                    className={`py-3 rounded-md font-bold border transition-colors ${
                      amount === p && !custom ? 'bg-orange-600 text-white border-orange-600' : 'border-slate-200 text-slate-700 hover:border-orange-500'
                    }`}
                  >
                    ${p}
                  </button>
                ))}
              </div>
              <label className="block">
                <span className="text-sm font-semibold text-slate-600">Custom amount (USD)</span>
                <input
                  type="number" min="1" max="10000" step="1" inputMode="numeric"
                  value={custom}
                  onChange={(e) => { setCustom(e.target.value); setAmount(Number(e.target.value)) }}
                  placeholder="Other amount"
                  className="mt-1 w-full border border-slate-200 rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </label>
              {error && <p role="alert" className="text-sm text-red-600 font-medium">{error}</p>}
              <button
                onClick={startCheckout}
                disabled={!validAmount || loading}
                className="w-full bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white py-4 rounded-md font-bold uppercase tracking-wider transition-colors"
              >
                {loading ? 'Loading…' : validAmount ? `Continue — $${amount}` : 'Enter an amount'}
              </button>
              <p className="flex items-center justify-center text-xs text-slate-500">
                <Lock className="h-3 w-3 mr-1" /> Secure payment powered by Stripe
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
